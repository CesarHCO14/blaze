<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model
{
    function List_User(){
        $result = $this->db->get('users');
        if($result->row()!=null){
			return $result;
		}else{
			return 0;
		}
	}

	function Add_User($first_name,$last_name,$email,$phone,$birth_date){
        $data = array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'phone' => $phone,
            'birth_date' => $birth_date
        );
        $this->db->insert('users', $data);
        return $this->db->insert_id();
	}

    function Get_User($id_user){
        $result = $this->db->get_where('users', array('id' => $id_user));
        return $result->row_array();
	}	

	function Update_User($id_user,$first_name,$last_name,$email,$phone,$birth_date){
        $data = array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'phone' => $phone,
            'birth_date' => $birth_date
        );
        $this->db->where('id', $id_user);
        $this->db->update('users',$data);
	}

	function Delete_User($id_user){
		$this->db->where('id', $id_user);
        $this->db->delete('users');
	}
}