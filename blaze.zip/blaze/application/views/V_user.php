<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Blaze</title>

	<link rel="stylesheet" href="<?php echo base_url();?>public/plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>public/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>public/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>public/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
	<div class="wrapper">

<div class="">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1>Users</h1>
				</div>
				<div class="col-sm-6">
                    <button class="btn btn-primary waves-effect waves-light" onclick="add_user()">Add User</button>
                </div>
			</div>
		</div>
	</section>

	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12">
	

					<div class="card">
						<div class="card-header">
							<h3 class="card-title">List of users</h3>
						</div>
						<div class="card-body">
							<table id="datatableuser" class="table table-bordered table-striped">
								<thead>
									<tr>
										<th>N°</th>
										<th>First Name</th>
										<th>Last Name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Birth date</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>
									<?php echo $users;?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
</div>

<div class="modal fade" id="modaluser" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form-modal-user">
      <div class="modal-body">
        <input type="hidden" name="id" id="id" class="form-control">
            <div class="form-group">
                <label class="label-control">First Name</label>
                <input type="text" name="first_name" id="first_name" class="form-control">
            </div>
            <div class="form-group">
                <label class="label-control">Last Name</label>
                <input type="text" name="last_name" id="last_name" class="form-control">
            </div>
            <div class="form-group">
                <label class="label-control">Email</label>
                <input type="email" name="email" id="email" class="form-control">
            </div>
            <div class="form-group">
                <label class="label-control">Phone</label>
                <input type="tel" name="phone" id="phone" class="form-control">
            </div>
            <div class="form-group">
                <label class="label-control">Birth date</label>
                <input type="date" name="birth_date" id="birth_date" class="form-control">
            </div>
      </div>
      </form>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary" id="btn_modal"><i class="icon-rocket"></i> Guardar</button>
      </div>
      
    </div>
  </div>
</div>

<script src="<?php echo base_url();?>public/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url();?>public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url();?>public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>public/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url();?>public/dist/js/demo.js"></script>
<script>
	$(function () {
		$("#datatableuser").DataTable();
	});

	function add_user(){
		save_method = "add";
		$("#modaluser").modal("show");
		$(".modal-title").text("Add User");
		$("#form-modal-user")[0].reset();
	}

	function update_user(id){
		save_method = "update";
		$("#form-modal-user")[0].reset();
		$.ajax({
			url : "<?php echo base_url();?>C_user/get_id/"+id,
			type: "GET",
			dataType: "JSON",
			success: function(data)
			{
				$("#modaluser").modal("show");				
				$(".modal-title").text("Update User");

				$("#id").val(data.id);
				$("#first_name").val(data.first_name);
				$("#last_name").val(data.last_name);
				$("#email").val(data.email);
				$("#phone").val(data.phone);
				$("#birth_date").val(data.birth_date);

			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				alert("Error");
			}
		});
	}

	$("#btn_modal").click(function(){
		
		var url;				    	
		if(save_method == "add"){
			url = "<?php echo base_url();?>C_user/add_user";
		}else {
			url = "<?php echo base_url();?>C_user/update_user";
		}              
		$.ajax({
			type: "POST",
			cache: false,
			url: url,
			data: new FormData($("#form-modal-user")[0]),
			timeout: 3000,
			processData: false,
			contentType: false,
			beforeSend: function() {
				$("#btn_modal").text("Espere un momento");
			}, 
			success: function(data){
				
				location.reload();
			},
			error: function (data,request, status, error) {
				alert("Error al guardar");
			}
		});
	});

	function delete_user(id){
		$.ajax({
			url:   "<?php echo base_url();?>C_user/delete_user/"+id,
			type:   "POST",
			dataType: "JSON",
			success:function(data){
				location.reload();
			},
			error: function(xhr, ajaxOptions, thrownError) {
				alert("error");
			}
		}); 
	}
</script>
</body>
</html>
