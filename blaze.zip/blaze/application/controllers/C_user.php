<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user extends CI_Controller 
{
    function __construct(){
        parent::__construct();
        $this->load->model('M_user');
    }

    public function index()
	{
        $data["users"]=$this->list_user();
		$this->load->view('V_user',$data);
	}

    public function list_user()
	{
		$result = $this->M_user->List_User();
		$html="";
		if ($result) {
			foreach ($result->result() as $row) {
				$html.='
					<tr>
						<td>'.$row->id.'</td>
						<td>'.$row->first_name.'</td>
						<td>'.$row->last_name.'</td>
						<td>'.$row->email.'</td>
						<td>'.$row->phone.'</td>
						<td>'.date("d-m-Y", strtotime($row->birth_date)).'</td>
						<td>
							<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Editar" onclick="update_user('.$row->id.')"><i class="fa fa-edit"></i> </a>
							<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Eliminar" onclick="delete_user('."'".$row->id."'".')"><i class="fa fa-trash"></i></a>
						</td>
					</tr>';
			}
		}
		return $html;
	}

	public function add_user()
	{
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$phone = $this->input->post('phone');
		$birth_date = $this->input->post('birth_date');
		$this->M_user->Add_User($first_name,$last_name,$email,$phone,$birth_date);
		echo json_encode(array("status" => TRUE));	
		
	}

	public function update_user()
	{	
		$id_user = $this->input->post('id');
		$first_name = $this->input->post('first_name');
		$last_name = $this->input->post('last_name');
		$email = $this->input->post('email');
		$phone = $this->input->post('phone');
		$birth_date = $this->input->post('birth_date');
		$insert = $this->M_user->Update_User($id_user,$first_name,$last_name,$email,$phone,$birth_date);
		echo json_encode(array("status" => TRUE));
	}

	public function get_id($id)
	{
		$data = $this->M_user->Get_User($id);
		echo json_encode($data);
	}

	public function delete_user($id)
	{
		$data = $this->M_user->Delete_User($id);
		echo json_encode($data);
	}

}